import SwiftUI

@main
struct LittleLemonRestaurantApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
